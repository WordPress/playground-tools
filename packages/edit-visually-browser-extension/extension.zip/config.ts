export const LOOPBACK_SW_URL = 'https://playground-editor-extension.pages.dev';
