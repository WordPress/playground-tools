export const __experimentalUseDialog =
	window.wp.compose.__experimentalUseDialog;
export const __experimentalUseDragging =
	window.wp.compose.__experimentalUseDragging;
export const __experimentalUseDropZone =
	window.wp.compose.__experimentalUseDropZone;
export const __experimentalUseFixedWindowList =
	window.wp.compose.__experimentalUseFixedWindowList;
export const __experimentalUseFocusOutside =
	window.wp.compose.__experimentalUseFocusOutside;
export const compose = window.wp.compose.compose;
export const createHigherOrderComponent =
	window.wp.compose.createHigherOrderComponent;
export const debounce = window.wp.compose.debounce;
export const ifCondition = window.wp.compose.ifCondition;
export const pipe = window.wp.compose.pipe;
export const pure = window.wp.compose.pure;
export const throttle = window.wp.compose.throttle;
export const useAsyncList = window.wp.compose.useAsyncList;
export const useConstrainedTabbing = window.wp.compose.useConstrainedTabbing;
export const useCopyOnClick = window.wp.compose.useCopyOnClick;
export const useCopyToClipboard = window.wp.compose.useCopyToClipboard;
export const useDebounce = window.wp.compose.useDebounce;
export const useDisabled = window.wp.compose.useDisabled;
export const useFocusOnMount = window.wp.compose.useFocusOnMount;
export const useFocusReturn = window.wp.compose.useFocusReturn;
export const useFocusableIframe = window.wp.compose.useFocusableIframe;
export const useInstanceId = window.wp.compose.useInstanceId;
export const useIsomorphicLayoutEffect =
	window.wp.compose.useIsomorphicLayoutEffect;
export const useKeyboardShortcut = window.wp.compose.useKeyboardShortcut;
export const useMediaQuery = window.wp.compose.useMediaQuery;
export const useMergeRefs = window.wp.compose.useMergeRefs;
export const usePrevious = window.wp.compose.usePrevious;
export const useReducedMotion = window.wp.compose.useReducedMotion;
export const useRefEffect = window.wp.compose.useRefEffect;
export const useResizeObserver = window.wp.compose.useResizeObserver;
export const useStateWithHistory = window.wp.compose.useStateWithHistory;
export const useThrottle = window.wp.compose.useThrottle;
export const useViewportMatch = window.wp.compose.useViewportMatch;
export const useWarnOnChange = window.wp.compose.useWarnOnChange;
export const withGlobalEvents = window.wp.compose.withGlobalEvents;
export const withInstanceId = window.wp.compose.withInstanceId;
export const withSafeTimeout = window.wp.compose.withSafeTimeout;
export const withState = window.wp.compose.withState;
