export const __experimentalGetSettings =
	window.wp.date.__experimentalGetSettings;
export const date = window.wp.date.date;
export const dateI18n = window.wp.date.dateI18n;
export const format = window.wp.date.format;
export const getDate = window.wp.date.getDate;
export const getSettings = window.wp.date.getSettings;
export const gmdate = window.wp.date.gmdate;
export const gmdateI18n = window.wp.date.gmdateI18n;
export const humanTimeDiff = window.wp.date.humanTimeDiff;
export const isInTheFuture = window.wp.date.isInTheFuture;
export const setSettings = window.wp.date.setSettings;
