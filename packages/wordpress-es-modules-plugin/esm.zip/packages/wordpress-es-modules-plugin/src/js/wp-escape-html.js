export const escapeAmpersand = window.wp.escapeHtml.escapeAmpersand;
export const escapeAttribute = window.wp.escapeHtml.escapeAttribute;
export const escapeEditableHTML = window.wp.escapeHtml.escapeEditableHTML;
export const escapeHTML = window.wp.escapeHtml.escapeHTML;
export const escapeLessThan = window.wp.escapeHtml.escapeLessThan;
export const escapeQuotationMark = window.wp.escapeHtml.escapeQuotationMark;
export const isValidAttributeName = window.wp.escapeHtml.isValidAttributeName;
