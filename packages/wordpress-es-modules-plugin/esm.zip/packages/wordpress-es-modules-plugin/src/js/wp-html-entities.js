export const decodeEntities = window.wp.htmlEntities.decodeEntities;
