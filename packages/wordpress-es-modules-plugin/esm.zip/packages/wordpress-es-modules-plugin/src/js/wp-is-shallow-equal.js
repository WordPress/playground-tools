export const default = window.wp.isShallowEqual.default;
export const isShallowEqualArrays = window.wp.isShallowEqual.isShallowEqualArrays;
export const isShallowEqualObjects = window.wp.isShallowEqual.isShallowEqualObjects;