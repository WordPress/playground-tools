export const ShortcutProvider = window.wp.keyboardShortcuts.ShortcutProvider;
export const __unstableUseShortcutEventMatch =
	window.wp.keyboardShortcuts.__unstableUseShortcutEventMatch;
export const store = window.wp.keyboardShortcuts.store;
export const useShortcut = window.wp.keyboardShortcuts.useShortcut;
