export const store = window.wp.notices.store;
