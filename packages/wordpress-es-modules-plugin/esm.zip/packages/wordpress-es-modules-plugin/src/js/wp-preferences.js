export const PreferenceToggleMenuItem =
	window.wp.preferences.PreferenceToggleMenuItem;
export const store = window.wp.preferences.store;
