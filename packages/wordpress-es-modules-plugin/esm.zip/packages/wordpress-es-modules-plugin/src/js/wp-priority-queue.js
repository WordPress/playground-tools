export const createQueue = window.wp.priorityQueue.createQueue;
