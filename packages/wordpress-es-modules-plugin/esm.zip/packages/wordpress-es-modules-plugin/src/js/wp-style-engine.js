export const compileCSS = window.wp.styleEngine.compileCSS;
export const getCSSRules = window.wp.styleEngine.getCSSRules;
