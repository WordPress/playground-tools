export const count = window.wp.wordcount.count;
