import { createElement } from '@wordpress/element';
import { registerCoreBlocks } from '@wordpress/block-library';

console.log('Here are some imports from ES modules:', {
	registerCoreBlocks,
	createElement,
});
