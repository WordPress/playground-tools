export const setup = window.wp.a11y.setup;
export const speak = window.wp.a11y.speak;
