export const autop = window.wp.autop.autop;
export const removep = window.wp.autop.removep;
