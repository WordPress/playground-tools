export const createBlobURL = window.wp.blob.createBlobURL;
export const getBlobByURL = window.wp.blob.getBlobByURL;
export const getBlobTypeByURL = window.wp.blob.getBlobTypeByURL;
export const isBlobURL = window.wp.blob.isBlobURL;
export const revokeBlobURL = window.wp.blob.revokeBlobURL;
