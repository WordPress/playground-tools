export const __experimentalGetCoreBlocks =
	window.wp.blockLibrary.__experimentalGetCoreBlocks;
export const __experimentalRegisterExperimentalCoreBlocks =
	window.wp.blockLibrary.__experimentalRegisterExperimentalCoreBlocks;
export const registerCoreBlocks = window.wp.blockLibrary.registerCoreBlocks;
