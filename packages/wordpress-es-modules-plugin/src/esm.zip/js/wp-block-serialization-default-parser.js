export const parse = window.wp.blockSerializationDefaultParser.parse;
