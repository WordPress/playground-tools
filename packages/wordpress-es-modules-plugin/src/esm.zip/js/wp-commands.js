export const CommandMenu = window.wp.commands.CommandMenu;
export const privateApis = window.wp.commands.privateApis;
export const store = window.wp.commands.store;
export const useCommand = window.wp.commands.useCommand;
export const useCommandLoader = window.wp.commands.useCommandLoader;
