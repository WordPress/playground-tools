export const EntityProvider = window.wp.coreData.EntityProvider;
export const __experimentalFetchLinkSuggestions =
	window.wp.coreData.__experimentalFetchLinkSuggestions;
export const __experimentalFetchUrlData =
	window.wp.coreData.__experimentalFetchUrlData;
export const __experimentalUseEntityRecord =
	window.wp.coreData.__experimentalUseEntityRecord;
export const __experimentalUseEntityRecords =
	window.wp.coreData.__experimentalUseEntityRecords;
export const __experimentalUseResourcePermissions =
	window.wp.coreData.__experimentalUseResourcePermissions;
export const store = window.wp.coreData.store;
export const useEntityBlockEditor = window.wp.coreData.useEntityBlockEditor;
export const useEntityId = window.wp.coreData.useEntityId;
export const useEntityProp = window.wp.coreData.useEntityProp;
export const useEntityRecord = window.wp.coreData.useEntityRecord;
export const useEntityRecords = window.wp.coreData.useEntityRecords;
export const useResourcePermissions = window.wp.coreData.useResourcePermissions;
