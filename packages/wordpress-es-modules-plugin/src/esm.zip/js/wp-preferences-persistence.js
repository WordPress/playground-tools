export const __unstableCreatePersistenceLayer =
	window.wp.preferencesPersistence.__unstableCreatePersistenceLayer;
export const create = window.wp.preferencesPersistence.create;
