export const displayName = window.wp.serverSideRender.displayName;
