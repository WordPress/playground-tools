export const next = window.wp.shortcode.next;
export const replace = window.wp.shortcode.replace;
export const string = window.wp.shortcode.string;
export const regexp = window.wp.shortcode.regexp;
export const attrs = window.wp.shortcode.attrs;
export const fromMatch = window.wp.shortcode.fromMatch;
