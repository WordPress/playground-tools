export const ifViewportMatches = window.wp.viewport.ifViewportMatches;
export const store = window.wp.viewport.store;
export const withViewportMatch = window.wp.viewport.withViewportMatch;
